<!-- Modal para mostrar el PDF -->
<div class="modal fade" id="modalPdf" tabindex="-1" aria-labelledby="modalPdfLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-body">
                <iframe id="pdfViewer" width="100%" height="600px"></iframe>
            </div>
        </div>
    </div>
</div>
