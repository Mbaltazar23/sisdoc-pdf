</div>
    <script src="js/fontawesome.js"></script>
    <script src="js/sweetalert.min.js"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
